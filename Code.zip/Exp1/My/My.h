#ifndef __MY__
#define __MY__

#include "main.h"

void MyGetInput(void);

void MyLogicScan(void);

void MyOutPut(void);


#endif