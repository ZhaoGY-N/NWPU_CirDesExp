#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "adc.h"
#include "dac.h"
#include "key.h"
#include "led.h"
#include "timer.h"
#include "string.h"
#include "usart3.h"

//***************************************************************//
//****PA5为adc采样口or,		pb10 串口屏tx,pb11 串口屏rx,    pd2产生PWM方波
//***************************************************************//
extern int time;
u16 adcx;
u16 len,fire_grade = 0,res = 0;
int main(void)
{ 
	u8 data_to_send[2] = {0};
	float a_temp=0;                     	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//设置系统中断优先级分组2
	delay_init(168);                               //初始化延时函数
	uart_init(115200);		                         //初始化串口波特率为115200
	usart3_init(115200);
	LED_Init();	        //led初始化
	TIM3_Int_Init(50-1,8400-1);//定时器时钟84M，分频系数8400，所以84M/8400=10Khz的计数频率，计数100次为10ms，频率为50HZ
	Adc_Init(); 				//adc初始化
	KEY_Init(); 				//按键初始化
	
//	LED0 = 0;						//工作，低电平有效
	while(1)
	{
		//0xff 0xff 包头
		//过流检测
		//adc采样，使用的通道是PA5，参考电压是3.3V
		adcx=Get_Adc_Average(ADC_Channel_5,200);
		a_temp=(float)adcx*(2.5/4096.0);        //（这里ADC的参考电压需要确定）电流值
		if(adcx >=1300)
		{
			res = 1;
			fire_grade = 1;
		}
		if(adcx <1300 &&adcx >= 1000)
		{
			res = 2;
			fire_grade = 2;
		}
		if(adcx < 1000&&adcx >= 940)
		{
			res = 3;
			fire_grade = 3;
		}
		if(adcx <940&&adcx >= 850)
		{
			res = 4;
			fire_grade = 4;
		}
		if(adcx <850&&adcx >= 800)
		{
			res = 5;
			fire_grade = 5;
		}
		if(adcx <800&&adcx >= 760)
		{
			res = 6;
			fire_grade = 6;
		}
		if(adcx <760&&adcx >= 750)
		{
			res = 7;
			fire_grade = 7;
		}
		if(adcx <750&&adcx >= 740)
		{
			res = 8;
			fire_grade = 8;
		}
		if(adcx <740&&adcx >= 730)
		{
			res = 9;
			fire_grade = 9;
		}
		if(adcx < 730)
		{
			res = 10;
			fire_grade = 10;
		}
		if(time>=20)
		{
		time = 0;
		memcpy(&data_to_send,&fire_grade,2);
		USART_SendData(USART3,0xA5);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,0x5A);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,0x05);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,0x82);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,0x00);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,0x30);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,data_to_send[1]);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,data_to_send[0]);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕 
			
		memcpy(&data_to_send,&res,2);
		USART_SendData(USART3,0xA5);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,0x5A);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,0x05);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,0x82);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,0x00);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,0x20);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,data_to_send[1]);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		USART_SendData(USART3,data_to_send[0]);  
		while(USART_GetFlagStatus(USART3,USART_FLAG_TC)!=SET);//循环发送,直到发送完毕
		printf("%d\r\n",fire_grade);
		printf("%d\r\n",adcx);
		}
		if(USART3_RX_STA&0x8000)
				{
				  len=USART3_RX_STA&0x3fff;
					if(USART3_RX_BUF[len-1]== 0x11)
					{
					}
					if(USART3_RX_BUF[len-1]== 0x22)
					{
					}
					USART3_RX_STA=0;
			  }	
	}	
}
